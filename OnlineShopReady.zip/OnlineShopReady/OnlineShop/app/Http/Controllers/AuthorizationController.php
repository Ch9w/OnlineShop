<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Auth;


class AuthorizationController extends Controller
{
    public function login(Request $request) {
        $request->flash();
        if (Auth::check()) {
            return redirect()->intended(route('user.aboutus'));
        }
        $formFields = $request->only(['login', 'password']);
        if (Auth::attempt($formFields)) { 
            return redirect()->intended(route('user.aboutus'));
        }
        return redirect(route('user.login'))->withErrors(["login" => "Не удалость авторизоваться"]);
    }
}
