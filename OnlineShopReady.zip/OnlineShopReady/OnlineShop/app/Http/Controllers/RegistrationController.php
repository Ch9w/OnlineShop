<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Validator;
use Illuminate\Support\Facades\DB;

class RegistrationController extends Controller
{
    public function save(Request $request)
    {
        if (Auth::check()) {
            return redirect(route('user.aboutus'));
        }
        $request->flash();

        $validateFields = $request->validate([
            'name' => 'required',
            'surname' => 'required',
            'login' => 'required',
            'email' => 'required|email',
            'password' => 'required',
            'password_repeat' => 'required',
        ]);
        $name = $validateFields['name'];
        $surname = $validateFields['surname'];
        $patronymic = $request->input('patronymic');
        $login = $validateFields['login'];
        $email = $validateFields['email'];
        $password = $validateFields['password'];

        if (User::where('login', $login)->exists()) {
            return redirect(route('user.registration'))->withErrors(["login" => "Такой login уже зарегистрирован"]);
        }
        if (User::where('email', $email)->exists()) {
            return redirect(route('user.registration'))->withErrors(["email" => "Такой email уже зарегистрирован"]);
        }
        if ($password != $request->input('password_repeat')) {
            return redirect(route('user.registration'))->withErrors(["password" => "Пароли не совпадают"]);
        }
        if ($request->input('rules') != 'true') {
            return redirect(route('user.registration'))->withErrors(["rules" => "Согласитесь с правилами регистрации"]);
        }
        $user = User::create([
            'name' => $name,
            'surname' => $surname,
            'patronymic' => $patronymic,
            'login' => $login,
            'email' => $email,
            'password' => $password,
            'role' => 'user'
        ]);
        DB::table("basket")->insert([
            'id_user'=>$user->id,
            'status' => 'select'
        ]);
        if ($user) {
            Auth::login($user);
            return redirect()->to(route('user.aboutus'));
        }
        return redirect(route('user.login'))->withErrors([
            'formError' => 'Произошла ошибка при сохранении пользователя'
        ]);
    }
}
