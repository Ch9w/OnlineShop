<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Symfony\Contracts\Service\Attribute\Required;
use Illuminate\Support\Facades\Session;

class CatalogController extends Controller
{
    public function catalog(Request $request)
    {
        $selectedsorting = $request->input('sorting');
        Session::put('sorting', $selectedsorting);
        $selectedorderBy = $request->input('orderBy');
        Session::put('orderBy', $selectedorderBy);
        $selectedcategory = $request->input('category');
        Session::put('category', $selectedcategory);

        $categories = DB::table('category')->get();
        if ($request->has('category')) {
            $selectedCategory = $request->input('category');
            if ($selectedCategory == 'all') {
                if ($request->input('orderBy') == "ADESC") {
                    $catalog = DB::table('products')->where('quantity', ">", 0)->latest($request->input('sorting'))->get();
                } else if ($request->input('orderBy') == "DESC") {
                    $catalog = DB::table('products')->where('quantity', ">", 0)->oldest($request->input('sorting'))->get();
                } else {
                    $catalog = DB::table('products')->where('quantity', ">", 0)->latest('date')->get();
                }
            } else {
                if ($request->input('orderBy') == "ADESC") {
                    $catalog = DB::table('products')->where('quantity', ">", 0)->where('id_category', $selectedCategory)->latest($request->input('sorting'))->get();
                } else if ($request->input('orderBy') == "DESC") {
                    $catalog = DB::table('products')->where('quantity', ">", 0)->where('id_category', $selectedCategory)->oldest($request->input('sorting'))->get();
                } else {
                    $catalog = DB::table('products')->where('quantity', ">", 0)->where('id_category', $selectedCategory)->latest('date')->get();
                }
            }
        } else {
            $catalog = DB::table('products')->where('quantity', ">", 0)->latest('date')->get();
        }
        if (Auth::check()) {
            if (Auth::user()->role == "admin") {
                $catalog = DB::table('products')->latest('date')->get();
                $idbusket = DB::table("basket")->where("id_user", Auth::id())->where("status", 'select')->first();
                $productsFromBasket = DB::table('basket_products')->where('id_busket', $idbusket->id)->select('id_products')->get();
                return view('catalog', ['catalog' => $catalog, 'categories' => $categories, 'productsFromBasket' => $productsFromBasket]);
            }
            $idbusket = DB::table("basket")->where("id_user", Auth::id())->where("status", 'select')->first();
            $productsFromBasket = DB::table('basket_products')->where('id_busket', $idbusket->id)->select('id_products')->get();
            return view('catalog', ['catalog' => $catalog, 'categories' => $categories, 'productsFromBasket' => $productsFromBasket]);
        } else {
            return view('catalog', ['catalog' => $catalog, 'categories' => $categories]);
        }
    }
    public function ProductFromBusket(Request $request)
    {
        $idProduct = $request->input('idProduct');
        $selectedsorting = $request->input('sorting');
        Session::put('sorting', $selectedsorting);
        $selectedorderBy = $request->input('orderBy');
        Session::put('orderBy', $selectedorderBy);
        $selectedcategory = $request->input('category');
        Session::put('category', $selectedcategory);

        $idbusket = DB::table("basket")->where("id_user", Auth::id())->where("status", 'select')->first();
        if (isset($_POST["addProductFromBusket"])) {
            DB::table("basket_products")->insert([
                'id_busket' => $idbusket->id,
                'id_products' => $idProduct,
                'quantity' => 1
            ]);
        }
        if (isset($_POST["delProductFromBusket"])) {
            DB::table('basket_products')->where('id_busket', $idbusket->id)->where('id_products', $idProduct)->delete();
        }
        if (isset($_POST["delProduct"])) {
            DB::table("products")->where("id", $request->input("delProduct"))->delete();
            $catalog = DB::table('products')->latest('date')->get();
            $idbusket = DB::table("basket")->where("id_user", Auth::id())->where("status", 'select')->first();
            $productsFromBasket = DB::table('basket_products')->where('id_busket', $idbusket->id)->select('id_products')->get();
            $categories = DB::table('category')->get();
            return view('catalog', ['catalog' => $catalog, 'categories' => $categories, 'productsFromBasket' => $productsFromBasket]);
        }
        if (isset($_POST["changeProduct"])) {
            $id = $request->input("changeProduct");
            $thisProduct = DB::table("products")->where("id", $id)->first();
            $categories = DB::table('category')->get();
            return view("changeProduct", ['thisProduct' => $thisProduct, 'categories' => $categories]);
        }
        if (isset($_POST["redProduct"])) {
            $product_name = $request->input('addProduct-name');
            $product_id_category = $request->input('addProduct-selectCategory');
            $product_price = $request->input('addProduct-price');
            $product_quantity = $request->input('addProduct-quantity');
            $product_country = $request->input('addProduct-country');
            $product_yearrelease = $request->input('addProduct-yearrelease');
            $product_model = $request->input('addProduct-model');


            $categories = DB::table('category')->get();

            if ($product_name == "") {
                return view('admin', ['categories' => $categories, 'errorname1' => '1']);
            }
            if ($product_price == "") {
                return view('admin', ['categories' => $categories, 'errorname2' => '2']);
            }
            if ($product_quantity == "") {
                return view('admin', ['categories' => $categories, 'errorname3' => '3']);
            }
            if ($product_country == "") {
                return view('admin', ['categories' => $categories, 'errorname4' => '4']);
            }
            if ($product_yearrelease == "") {
                return view('admin', ['categories' => $categories, 'errorname5' => '5']);
            }
            if ($product_model == "") {
                return view('admin', ['categories' => $categories, 'errorname6' => '6']);
            }

            DB::table('products')->where('id', $request->input('idProduct'))->update([
                'name' => $product_name,
                'id_category' => $product_id_category,
                'price' => $product_price,
                'quantity' => $product_quantity,
                'country' => $product_country,
                'yearrelease' => $product_yearrelease,
                'model' => $product_model,
                'date' => date("Y-m-d")
            ]);
            $catalog = DB::table('products')->latest('date')->get();
            $idbusket = DB::table("basket")->where("id_user", Auth::id())->where("status", 'select')->first();
            $productsFromBasket = DB::table('basket_products')->where('id_busket', $idbusket->id)->select('id_products')->get();
            return view('catalog', ['catalog' => $catalog, 'categories' => $categories, 'productsFromBasket' => $productsFromBasket]);
        }

        $categories = DB::table('category')->get();
        if ($request->has('category')) {
            $selectedCategory = $request->input('category');
            if ($selectedCategory == 'all') {
                if ($request->input('orderBy') == "ADESC") {
                    $catalog = DB::table('products')->where('quantity', ">", 0)->latest($request->input('sorting'))->get();
                } else if ($request->input('orderBy') == "DESC") {
                    $catalog = DB::table('products')->where('quantity', ">", 0)->oldest($request->input('sorting'))->get();
                } else {
                    $catalog = DB::table('products')->where('quantity', ">", 0)->latest('date')->get();
                }
            } else {
                if ($request->input('orderBy') == "ADESC") {
                    $catalog = DB::table('products')->where('quantity', ">", 0)->where('id_category', $selectedCategory)->latest($request->input('sorting'))->get();
                } else if ($request->input('orderBy') == "DESC") {
                    $catalog = DB::table('products')->where('quantity', ">", 0)->where('id_category', $selectedCategory)->oldest($request->input('sorting'))->get();
                } else {
                    $catalog = DB::table('products')->where('quantity', ">", 0)->where('id_category', $selectedCategory)->latest('date')->get();
                }
            }
        } else {
            $catalog = DB::table('products')->where('quantity', ">", 0)->latest('date')->get();
        }
        $productsFromBasket = DB::table('basket_products')->where('id_busket', $idbusket->id)->select('id_products')->get();
        return view('catalog', ['catalog' => $catalog, 'categories' => $categories, 'productsFromBasket' => $productsFromBasket]);
    }

    public function thistovar($id)
    {

        $idProduct = DB::table("products")->where('id', $id)->first();
        $idbusket = DB::table("basket")->where("id_user", Auth::id())->where("status", 'select')->first();

        $thistovar = DB::table('products')->find($id);
        $category = DB::table('category')->find($thistovar->id_category);

        if (Auth::check()) {
            $productsFromBasket = DB::table('basket_products')->where('id_busket', $idbusket->id)->select('id_products')->get();

            return view('thistovar', ['thistovar' => $thistovar, 'productsFromBasket' => $productsFromBasket, 'category' => $category, 'tovar' => $idProduct]);
        } else {
            return view('thistovar', ['thistovar' => $thistovar, 'category' => $category, 'tovar' => $idProduct]);
        }
    }
    public function thistovarlogic(Request $request, $id)
    {
        $idProduct = DB::table("products")->where('id', $id)->first();
        $idbusket = DB::table("basket")->where("id_user", Auth::id())->where("status", 'select')->first();
        if (isset($_POST["addProductFromBusket"])) {
            DB::table("basket_products")->insert([
                'id_busket' => $idbusket->id,
                'id_products' => $idProduct->id,
                'quantity' => 1
            ]);
        }
        if (isset($_POST["delProductFromBusket"])) {
            DB::table('basket_products')->where('id_busket', $idbusket->id)->where('id_products', $idProduct->id)->delete();
        }
        $productsFromBasket = DB::table('basket_products')->where('id_busket', $idbusket->id)->select('id_products')->get();


        $thistovar = DB::table('products')->find($id);
        $category = DB::table('category')->find($thistovar->id_category);
        return view('thistovar', ['thistovar' => $thistovar, 'category' => $category, 'productsFromBasket' => $productsFromBasket, 'tovar' => $idProduct]);
    }
}
