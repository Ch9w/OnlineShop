<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Symfony\Contracts\Service\Attribute\Required;

class AdminController extends Controller
{
    public function open()
    {
        if (Auth::check()) {
            if (Auth::user()->role == 'admin') {
                $categories = DB::table('category')->get();
                $ordersNEW = DB::table("orders")->where('status', 'новый')->get();
                $productsFromBasket = DB::table("basket_products")->get();
                $products = DB::table("products")->get();

                return view('admin', ['products' => $products, 'categories' => $categories, "ordersNEW" => $ordersNEW, 'productsFromBasket' => $productsFromBasket]);
            } else {
                return redirect(route('user.aboutus'));
            }
        } else {
            return view('login');
        }
    }
    public function operation(Request $request)
    {
        if (Auth::check()) {
            if (Auth::user()->role == 'admin') {
                if (isset($_POST["addCategory"])) {
                    $categoryName = $request->input('categoryName');
                    DB::table('category')->insert([
                        'name' => $categoryName,
                    ]);
                    $categories = DB::table('category')->get();
                    return view('admin', ['categories' => $categories, 'addCategory' => 'addCategory']);
                }
                if (isset($_POST["delCategory"])) {
                    $categoryId = $request->input('selectCategory');
                    DB::table('category')->where('id', $categoryId)->delete();
                    $categories = DB::table('category')->get();
                    return view('admin', ['categories' => $categories, 'delCategory' => 'delCategory']);
                }
                if (isset($_POST["addProduct"])) {

                    $product_name = $request->input('addProduct-name');
                    $product_id_category = $request->input('addProduct-selectCategory');
                    $product_price = $request->input('addProduct-price');
                    $product_quantity = $request->input('addProduct-quantity');
                    $product_country = $request->input('addProduct-country');
                    $product_yearrelease = $request->input('addProduct-yearrelease');
                    $product_model = $request->input('addProduct-model');


                    $categories = DB::table('category')->get();

                    if ($product_name == "") {
                        return view('admin', ['categories' => $categories, 'errorname1' => '1']);
                    }
                    if ($product_price == "") {
                        return view('admin', ['categories' => $categories, 'errorname2' => '2']);
                    }
                    if ($product_quantity == "") {
                        return view('admin', ['categories' => $categories, 'errorname3' => '3']);
                    }
                    if ($product_country == "") {
                        return view('admin', ['categories' => $categories, 'errorname4' => '4']);
                    }
                    if ($product_yearrelease == "") {
                        return view('admin', ['categories' => $categories, 'errorname5' => '5']);
                    }
                    if ($product_model == "") {
                        return view('admin', ['categories' => $categories, 'errorname6' => '6']);
                    }

                    $fn = null;
                    $fileName = null;
                    if ($request->has('image')) {
                        $fileName = time().'.'.$request->image->extension();
                        $request->image->move(public_path('images'), $fileName);
                    }

                    // dd($request);

                    // Storage::disk('local')->put('newfile.png', $file);

                    DB::table('products')->insert([
                        'name' => $product_name,
                        'id_category' => $product_id_category,
                        'price' => $product_price,
                        'quantity' => $product_quantity,
                        'country' => $product_country,
                        'yearrelease' => $product_yearrelease,
                        'model' => $product_model,
                        'date' => date("Y-m-d"),
                        'img_src' => $fileName
                    ]);
                    $categories = DB::table('category')->get();
                    $ordersNEW = DB::table("orders")->where('status', 'новый')->get();
                    $productsFromBasket = DB::table("basket_products")->get();
                    $products = DB::table("products")->get();

                    return view('admin', ['products' => $products, 'categories' => $categories, "ordersNEW" => $ordersNEW, 'productsFromBasket' => $productsFromBasket]);
                }
                if (isset($_POST["changestatus"])) {
                    $idNEWorder = $request->input("neworder");
                    DB::table("orders")->where("id", $idNEWorder)->update(["status" => $request->input("selectStatus")]);
                    if ($request->input("selectStatus") == "отменённый") {
                        DB::table("orders")->where("id", $idNEWorder)->update(["description" => $request->input("description")]);
                    }
                }
                $categories = DB::table('category')->get();
                $ordersNEW = DB::table("orders")->where('status', 'новый')->get();
                $productsFromBasket = DB::table("basket_products")->get();
                $products = DB::table("products")->get();

                return view('admin', ['products' => $products, 'categories' => $categories, "ordersNEW" => $ordersNEW, 'productsFromBasket' => $productsFromBasket]);
            } else {
                return redirect(route('user.aboutus'));
            }
        } else {
            return view('login');
        }
    }
}
