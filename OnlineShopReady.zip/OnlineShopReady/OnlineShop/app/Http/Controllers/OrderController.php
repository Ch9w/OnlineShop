<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Symfony\Contracts\Service\Attribute\Required;
use Illuminate\Support\Facades\Session;

class OrderController extends Controller
{
    public function getOrders()
    {
        $ordersNEW = DB::table("orders")->where("id_user", Auth::id())->where('status', 'новый')->get();
        $ordersOLD = DB::table("orders")->where("id_user", Auth::id())->where('status', "!=", 'новый')->get();
        $productsFromBasket = DB::table("basket_products")->get();
        $products = DB::table("products")->get();
        return view('orders', ['ordersNEW' => $ordersNEW, "ordersOLD" => $ordersOLD, 'products' => $products, 'productsFromBasket' => $productsFromBasket]);
    }
    public function postOrders(Request $request)
    {
        if (isset($_POST["delNEWorder"])) {
            $iddelNEWorder = $request->input("neworder");
            $idDelBasket = DB::table("orders")->where("id", $iddelNEWorder)->first();
            DB::table("orders")->where("id", $iddelNEWorder)->delete();
            DB::table("basket")->where('id', $idDelBasket->id_basket)->delete();
            DB::table("basket_products")->where('id_busket', $idDelBasket->id_basket)->delete();
        }
        $ordersNEW = DB::table("orders")->where("id_user", Auth::id())->where('status', 'новый')->get();
        $ordersOLD = DB::table("orders")->where("id_user", Auth::id())->where('status', "!=", 'новый')->get();
        $productsFromBasket = DB::table("basket_products")->get();
        $products = DB::table("products")->get();
        return view('orders', ['ordersNEW' => $ordersNEW, "ordersOLD" => $ordersOLD, 'products' => $products, 'productsFromBasket' => $productsFromBasket]);
    }
}
