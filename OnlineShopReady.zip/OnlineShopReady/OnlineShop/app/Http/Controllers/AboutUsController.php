<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AboutUsController extends Controller
{
    public function aboutus() {
        $products = DB::table('products')->latest('date')->take(5)->get();
        return view('aboutus', ['newproducts' =>$products]);
    }
}
