<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Symfony\Contracts\Service\Attribute\Required;
use Illuminate\Support\Facades\Session;

class BasketController extends Controller
{
    public function getBusket()
    {
        if (Auth::check()) {
            $products = DB::table("products")->get();
            $idbusket = DB::table("basket")->where("id_user", Auth::id())->where("status", 'select')->first();
            $productsFromBasket = DB::table('basket_products')->where('id_busket', $idbusket->id)->get();
            return view('basket', ['products' => $products, "productsFromBasket" => $productsFromBasket]);
        } else {
            return view('login');
        }
    }
    public function postBusket(Request $request)
    {
        if (Auth::check()) {
            if (isset($_POST['increaseProduct'])) {
                $thisid = $request->input('idProduct');
                $idbusket = DB::table("basket")->where("id_user", Auth::id())->where("status", 'select')->first();
                $maxquantity = DB::table("products")->where('id', $thisid)->first();
                $productFromBasket = DB::table('basket_products')->where('id_busket', $idbusket->id)->where("id_products", $thisid)->first();
                if (($productFromBasket->quantity) + 1 <= $maxquantity->quantity) {
                    DB::table('basket_products')->where('id_busket', $idbusket->id)->where("id_products", $thisid)->increment('quantity');
                }
            }
            if (isset($_POST['reduceProduct'])) {
                $thisid = $request->input('idProduct');
                $idbusket = DB::table("basket")->where("id_user", Auth::id())->where("status", 'select')->first();
                $maxquantity = DB::table("products")->where('id', $thisid)->first();
                $productFromBasket = DB::table('basket_products')->where('id_busket', $idbusket->id)->where("id_products", $thisid)->first();
                if (($productFromBasket->quantity) > 1) {
                    DB::table('basket_products')->where('id_busket', $idbusket->id)->where("id_products", $thisid)->decrement('quantity');
                }
            }
            if (isset($_POST['deleteProduct'])) {
                $thisid = $request->input('idProduct');
                $idbusket = DB::table("basket")->where("id_user", Auth::id())->where("status", 'select')->first();
                DB::table('basket_products')->where('id_busket', $idbusket->id)->where("id_products", $thisid)->delete();
            }
            if (isset($_POST['orderBasket'])) {
                if (Auth::attempt(['login' => DB::table("users")->where('id',Auth::id())->first()->login, 'password' => $request->input("password")])) {
                    $idBusket = DB::table("basket")->where("id_user", Auth::id())->where("status", 'select')->first();
                    $idbusket = DB::table("basket")->where("id_user", Auth::id())->where("status", 'select')->update(['status' => 'ordered']);
                    DB::table("basket")->insert([
                        'id_user' => Auth::id(),
                        'status' => 'select'
                    ]);

                    DB::table("orders")->insert([
                        'id_user' => Auth::id(),
                        'id_basket' => $idBusket->id,
                        'status' => 'новый'
                    ]);
                } else {
                    $products = DB::table("products")->get();
                    $idbusket = DB::table("basket")->where("id_user", Auth::id())->where("status", 'select')->first();
                    $productsFromBasket = DB::table('basket_products')->where('id_busket', $idbusket->id)->get();
                    return view('basket', ['products' => $products, "productsFromBasket" => $productsFromBasket, 'errorpassword' => '1']);
                }
            }


            $products = DB::table("products")->get();
            $idbusket = DB::table("basket")->where("id_user", Auth::id())->where("status", 'select')->first();
            $productsFromBasket = DB::table('basket_products')->where('id_busket', $idbusket->id)->get();
            return view('basket', ['products' => $products, "productsFromBasket" => $productsFromBasket]);
        } else {
            return view('login');
        }
    }
}
