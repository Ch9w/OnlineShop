<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        html,
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif
        }

        a {
            text-decoration: none;
            color: black;
        }

        header {
            font-size: 24px;
            background-color: rgb(200, 200, 200);
            display: flex;
            justify-content: center;
        }

        .header-div1 {
            width: 90%;
            display: flex;
            justify-content: space-between;
        }

        .content {
            margin: 0 auto;
            width: fit-content;
            display: flex;
            flex-direction: column;
            align-items: 'center';
        }

        span {
            color: grey;
            font-size: 32px;
        }
    </style>
</head>

<body>
    <header>
        <div class="header-div1">
            <div>
                <a href='aboutus'>Copy Star</a>
            </div>
            <div>
                <a href='catalog'>Каталог</a>
                <a href='wherefindus'>Где нас найти?</a>
            </div>
            <div>
                <?php if(Auth::check()): ?>
                    <a href='basket'>Корзина</a>
                    <a href='orders'>Заказы</a>
                    <a href='logout'>выйти</a>
                <?php else: ?>
                    <a href='login'>Вход</a>
                <?php endif; ?>
            </div>
        </div>
    </header>
    <div class="content">
        <h1>Где нас найти?</h1>
        <div style="position:relative;overflow:hidden;"><a
                href="https://yandex.ru/maps/11164/kamensk-uralskiy/?utm_medium=mapframe&utm_source=maps"
                style="color:#eee;font-size:12px;position:absolute;top:0px;">Каменск‑Уральский</a><a
                href="https://yandex.ru/maps/geo/kamensk_uralskiy/53159399/?ll=61.931239%2C56.416834&utm_medium=mapframe&utm_source=maps&z=11.44"
                style="color:#eee;font-size:12px;position:absolute;top:14px;">Каменск-Уральский —
                Яндекс Карты</a><iframe
                src="https://yandex.ru/map-widget/v1/?ll=61.931239%2C56.416834&mode=search&ol=geo&ouri=ymapsbm1%3A%2F%2Fgeo%3Fdata%3DCgg1MzE1OTM5ORJY0KDQvtGB0YHQuNGPLCDQodCy0LXRgNC00LvQvtCy0YHQutCw0Y8g0L7QsdC70LDRgdGC0YwsINCa0LDQvNC10L3RgdC6LdCj0YDQsNC70YzRgdC60LjQuSIKDcqrd0IVNalhQg%2C%2C&z=11.44"
                width="560" height="400" frameborder="1" allowfullscreen="true"
                style="position:relative;"></iframe></div>
        <span>Контактные данные</span>
        <div>
            <p>Номер телефона: 999-999-999</p>
            <p>Адрес: Каменск‑Уральский</p>
            <p>E-mail: CopyStar@mail.ru</p>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\OSPanel\domains\OnlineShop\resources\views/wherefindus.blade.php ENDPATH**/ ?>