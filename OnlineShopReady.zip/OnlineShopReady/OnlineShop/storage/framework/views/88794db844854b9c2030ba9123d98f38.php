<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        html,
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif
        }

        .h1-1 {
            text-align: center;
        }

        a {
            text-decoration: none;
            color: black;
        }

        header {
            font-size: 24px;
            background-color: rgb(200, 200, 200);
            display: flex;
            justify-content: center;
        }

        .header-div1 {
            width: 90%;
            display: flex;
            justify-content: space-between;
        }

        .content {
            margin: 0 auto;
            width: 90%;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        .card {
            align-items: center;
            text-align: center;
        }

        .img {
            height: 300px;
            width: fit-content;
            box-sizing: border-box;
            padding: 10px;
        }

        @media screen and (width <=1200px) {
            .cards {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media screen and (width <=768px) {
            .cards {
                grid-template-columns: repeat(1, 1fr);
            }
        }
    </style>
</head>

<body>
    <header>
        <div class="header-div1">
            <div>
                <a href='aboutus'>Copy Star</a>
            </div>
            <div>
                <a href='catalog'>Каталог</a>
                <a href='wherefindus'>Где нас найти?</a>
            </div>
            <div>
                <?php if(Auth::check()): ?>
                    <a href='basket'>Корзина</a>
                    <a href='orders'>Заказы</a>
                    <a href='logout'>выйти</a>
                <?php else: ?>
                    <a href='login'>Вход</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <div class="content">
        <h1 class="h1-1">Каталог товаров</h1>
        <form style ="margin-bottom: 10px;" action="catalog" method="GET">
            <table>
                <tr>
                    <td>Упорядочить товары по </td>
                    <td>
                        <select name="sorting">
                            <option value="date" <?php echo e(Session::get('sorting') == 'date' ? 'selected' : ''); ?>>новизне
                            </option>
                            <option value="yearrelease"
                                <?php echo e(Session::get('sorting') == 'yearrelease' ? 'selected' : ''); ?>>году производства
                            </option>
                            <option value="name" <?php echo e(Session::get('sorting') == 'name' ? 'selected' : ''); ?>>
                                наименованию</option>
                            <option value="price" <?php echo e(Session::get('sorting') == 'price' ? 'selected' : ''); ?>>цене
                            </option>
                        </select>
                        <select name="orderBy">
                            <option value="ADESC" <?php echo e(Session::get('orderBy') == 'ADESC' ? 'selected' : ''); ?>>по
                                убыванию</option>
                            <option value="DESC" <?php echo e(Session::get('orderBy') == 'DESC' ? 'selected' : ''); ?>>по
                                возрастанию</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Выбрать категорию </td>
                    <td>
                        <select name="category">
                            <option value="all"<?php echo e(Session::get('category') == 'all' ? 'selected' : ''); ?>>всё</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"
                                    <?php echo e(Session::get('category') == $category->id ? 'selected' : ''); ?>>
                                    <?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                </tr>
            </table>
            <input type="submit" name="search" value="Найти">
        </form>
        <div class="cards">
            <?php $__currentLoopData = $catalog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tovar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="card">
                        <a href="thistovar/<?php echo e($tovar->id); ?>">
                            <img src="<?php echo e(asset('images/' . $tovar->img_src)); ?>" class="card-img-top mx-auto img">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($tovar->name); ?></h5>
                                <p class="card-text"><?php echo e($tovar->price); ?> рублей</p>
                                <?php if(Auth::check()): ?>
                                    <?php
                                    $fromBusket = 0;
                                    ?>
                                    <?php $__currentLoopData = $productsFromBasket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productFromBasket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($productFromBasket->id_products == $tovar->id): ?>
                                            <?php
                                            $fromBusket++;
                                            ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($fromBusket > 0): ?>
                                        <input hidden name="idProduct" value="<?php echo e($tovar->id); ?>">
                                        <input type="submit" name="delProductFromBusket" class="btn btn-warning"
                                            value="В корзине">
                                    <?php else: ?>
                                        <input hidden name="idProduct" value="<?php echo e($tovar->id); ?>">
                                        <input type="submit" name="addProductFromBusket" class="btn btn-primary"
                                            value="В корзину">
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </a>
                    </div>
                </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</body>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
</script>

</html>
<?php /**PATH D:\OSPanel\domains\OnlineShop\resources\views/catalog.blade.php ENDPATH**/ ?>