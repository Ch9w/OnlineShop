<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        html,
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif
        }

        .h1-1 {
            text-align: center;
        }

        a {
            text-decoration: none;
            color: black;
        }

        header {
            font-size: 24px;
            background-color: rgb(200, 200, 200);
            display: flex;
            justify-content: center;
        }

        .header-div1 {
            width: 90%;
            display: flex;
            justify-content: space-between;
        }

        .content {
            margin: 0 auto;
            width: 90%;
        }

        .content-1 {
            display: flex;
            width: fit-content;
            margin: 0 auto
        }

        .img {
            height: 400px;
            padding: 10px
        }

        .characteristic {
            display: flex;
            flex-direction: column;
            justify-content: center;
            font-size: 24px;
        }
    </style>
</head>

<body>
    <header>
        <div class="header-div1">
            <div>
                <a href='<?php echo e(URL::to("/aboutus")); ?>'>Copy Star</a>
            </div>
            <div>
                <a href='<?php echo e(URL::to("/catalog")); ?>'>Каталог</a>
                <a href='<?php echo e(URL::to("/wherefindus")); ?>'>Где нас найти?</a>
            </div>
            <div>
                <?php if(Auth::check()): ?>
                    <a href='<?php echo e(URL::to("/basket")); ?>'>Корзина</a>
                    <a href='<?php echo e(URL::to("/orders")); ?>'>Заказы</a>
                    <a href='<?php echo e(URL::to("/logout")); ?>'>выйти</a>
                <?php else: ?>
                    <a href='<?php echo e(URL::to("/login")); ?>'>Вход</a>
                <?php endif; ?>
            </div>
        </div>
    </header>
    <div class="content">
        <div class="content-1">
            <div><img class="img" src="<?php echo e(asset('images/' . $thistovar->img_src)); ?>"
                    class="card-img-top w-75 mx-auto"></div>
            <div class="characteristic">
                <span><b>Название: </b><span>
                <span><?php echo e($thistovar->name); ?></span><br>
                <span><b>Категория: </b><span>
                <span><?php echo e($category->name); ?></span><br>
                <span><b>Цена: </b><span>
                <span><?php echo e($thistovar->price); ?> рублей</span><br>
                <span><b>Характеристики</b><span><br>
                <span><b>Страна производитель: </b><span>
                <span><?php echo e($thistovar->country); ?></span><br>
                <span><b>Год выпуска: </b><span>
                <span><?php echo e($thistovar->yearrelease); ?></span><br>
                <span><b>Модель: </b><span>
                <span><?php echo e($thistovar->model); ?></span><br>
                <?php if(Auth::check()): ?>
                    <?php
                        $fromBusket = 0;
                    ?>
                    <?php $__currentLoopData = $productsFromBasket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productFromBasket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($productFromBasket->id_products == $tovar->id): ?>
                            <?php
                                $fromBusket++;
                            ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($fromBusket > 0): ?>
                    <form action="<?php echo e(URL::to('thistovar/'.$tovar->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input hidden name="idProduct" value="<?php echo e($tovar->id); ?>">
                        <input type="submit" name="delProductFromBusket" class="btn btn-warning"
                        value="В корзине">
                    </form>
                    <?php else: ?>
                    <form action="<?php echo e(URL::to('thistovar/'.$tovar->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input hidden name="idProduct" value="<?php echo e($tovar->id); ?>">
                        <input type="submit" name="addProductFromBusket" class="btn btn-primary"
                        value="В корзину">
                    </form>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
</script>

</html>
<?php /**PATH C:\OSPanel\domains\lomov\OnlineShop\resources\views/thistovar.blade.php ENDPATH**/ ?>