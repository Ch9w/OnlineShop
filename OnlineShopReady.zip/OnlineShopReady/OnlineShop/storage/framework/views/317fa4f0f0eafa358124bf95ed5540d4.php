<form method='POST' action="login">
    <?php echo csrf_field(); ?>
    <h1>Авторизация</h1>
    <table>
        <tr>
            <td>name</td>
            <td><input type="text" name="login" value=""></td>
        </tr>
        <tr>
            <td>password</td>
            <td><input type="text" name="password" value=""></td>
        </tr>
    </table>
    <button>Войти</button>
</form>
<style>
 body {
    display: flex;
    justify-content: center;
 }
</style>
<?php /**PATH C:\OSPanel\domains\lomov\OnlineShop\resources\views/authoriztion.blade.php ENDPATH**/ ?>