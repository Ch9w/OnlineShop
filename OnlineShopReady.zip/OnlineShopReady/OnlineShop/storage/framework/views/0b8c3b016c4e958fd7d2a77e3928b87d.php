<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        html,
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif
        }

        .h1-1 {
            text-align: center;
        }

        a {
            text-decoration: none;
            color: black;
        }

        header {
            font-size: 24px;
            background-color: rgb(200, 200, 200);
            display: flex;
            justify-content: center;
        }

        .header-div1 {
            width: 90%;
            display: flex;
            justify-content: space-between;
        }

        .content {
            margin: 0 auto;
            width: 90%;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }

        .card {
            align-items: center;
            text-align: center;
        }

        th {
            text-align: left;
        }

        table {
            margin: 0 auto;
        }

        .product {
            border: 1px solid gray;
            border-radius: 20px;
            padding: 10px;
            display: flex;
            margin-bottom: 10px;
        }

        .img {
            height: 200px;
            width: fit-content;
            box-sizing: border-box;
            padding: 10px;
        }

        .flexblock {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .flexbuttons {
            display: flex;
        }
    </style>
</head>

<body>
    <header>
        <div class="header-div1">
            <div>
                <a href='aboutus'>Copy Star</a>
            </div>
            <div>
                <a href='catalog'>Каталог</a>
                <a href='wherefindus'>Где нас найти?</a>
            </div>
            <div>
                <?php if(Auth::check()): ?>
                    <a href='basket'>Корзина</a>
                    <a href='orders'>Заказы</a>
                    <a href='logout'>выйти</a>
                <?php else: ?>
                    <a href='login'>Вход</a>
                <?php endif; ?>
            </div>
        </div>
    </header>
    <h1 class="h1-1">Это консоль администратора</h1>
    <div class="content">
        <h2 class="h1-1">Добавление товара</h2>

        <form class="h1-1" method="POST" action="catalog">
            <?php echo csrf_field(); ?>
            <input hidden name="idProduct" value="<?php echo e($thisProduct->id); ?>">
            <table>
                <?php if(isset($addproduct)): ?>
                    <div>Вы отредактировал товар</div>
                <?php endif; ?>
                <tr>
                    <th>Название</th>
                    <td><input type="text" name="addProduct-name" value="<?php echo e($thisProduct->name); ?>"></td>
                    <?php if(isset($errorname1)): ?>
                        <div>Поле "Имя" не может быть пустым</div>
                    <?php endif; ?>
                </tr>
                <tr>
                    <th>Категория</th>
                    <td>
                        <select name="addProduct-selectCategory">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($thisProduct->id_category == $category->id): ?>
                                    <?php $namecategory1 =  $category->name?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($thisProduct->id_category); ?>"><?php echo e($namecategory1); ?></option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($thisProduct->id_category != $category->id): ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Цена</th>
                    <td><input type="number" min="0" name="addProduct-price" value="<?php echo e($thisProduct->price); ?>">
                    </td>
                    <?php if(isset($errorname2)): ?>
                        <div>Поле "Цена" не может быть пустым</div>
                    <?php endif; ?>
                </tr>
                <tr>
                    <th>Количество</th>
                    <td><input type="number" min="0" name="addProduct-quantity"
                            value="<?php echo e($thisProduct->quantity); ?>"></td>
                    <?php if(isset($errorname3)): ?>
                        <div>Поле "Количество" не может быть пустым</div>
                    <?php endif; ?>
                </tr>
                <tr>
                    <th>Страна</th>
                    <td><input type="text" name="addProduct-country" value="<?php echo e($thisProduct->country); ?>"></td>
                    <?php if(isset($errorname4)): ?>
                        <div>Поле "Страна" не может быть пустым</div>
                    <?php endif; ?>
                </tr>
                <tr>
                    <th>Год выпуска</th>
                    <td><input type="number" min="1900" max="2024" step="1"
                            value="<?php echo e($thisProduct->yearrelease); ?>" name="addProduct-yearrelease"></td>
                    <?php if(isset($errorname5)): ?>
                        <div>Поле "Год выпуска" не может быть пустым</div>
                    <?php endif; ?>
                </tr>
                <tr>
                    <th>Модель</th>
                    <td><input type="text" name="addProduct-model" value="<?php echo e($thisProduct->model); ?>"></td>
                    <?php if(isset($errorname6)): ?>
                        <div>Поле "Модель" не может быть пустым</div>
                    <?php endif; ?>
                </tr>
                <tr>
                    <th>Картинка</th>
                    <td><input type="file" name="image" accept="image/png, image/jpeg"></td>
                </tr>
            </table>
            <input name="redProduct" type="submit" value="Отредактировать товар">
        </form>
    </div>
</body>

</html>
<?php /**PATH C:\OSPanel\domains\lomov\OnlineShop\resources\views/changeProduct.blade.php ENDPATH**/ ?>