<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        html,
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif
        }

        .h1-1 {
            text-align: center;
        }

        a {
            text-decoration: none;
            color: black;
        }

        header {
            font-size: 24px;
            background-color: rgb(200, 200, 200);
            display: flex;
            justify-content: center;
        }

        .header-div1 {
            width: 90%;
            display: flex;
            justify-content: space-between;
        }

        .content {
            margin: 0 auto;
            width: 90%;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }

        .card {
            align-items: center;
            text-align: center;
        }

        th {
            text-align: left;
        }

        table {
            margin: 0 auto;
        }
        .product {
            border: 1px solid gray;
            border-radius: 20px;
            padding: 10px;
            display: flex;
            margin-bottom: 10px;
        }

        .img {
            height: 200px;
            width: fit-content;
            box-sizing: border-box;
            padding: 10px;
        }

        .flexblock {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .flexbuttons {
            display: flex;
        }
    </style>
</head>

<body>
    <header>
        <div class="header-div1">
            <div>
                <a href='aboutus'>Copy Star</a>
            </div>
            <div>
                <a href='catalog'>Каталог</a>
                <a href='wherefindus'>Где нас найти?</a>
            </div>
            <div>
                <?php if(Auth::check()): ?>
                    <a href='basket'>Корзина</a>
                    <a href='orders'>Заказы</a>
                    <a href='logout'>выйти</a>
                <?php else: ?>
                    <a href='login'>Вход</a>
                <?php endif; ?>
            </div>
        </div>
    </header>
    <h1 class="h1-1">Это консоль администратора</h1>
    <div class="content">
        <h2 class="h1-1">Добавление товара</h2>

        <form class="h1-1" method="POST" action="admin">
            <?php echo csrf_field(); ?>
            <table>
                <?php if(isset($addproduct)): ?>
                    <div>Вы добавили товар</div>
                <?php endif; ?>
                <tr>
                    <th>Название</th>
                    <td><input type="text" name="addProduct-name"></td>
                    <?php if(isset($errorname1)): ?>
                        <div>Поле "Имя" не может быть пустым</div>
                    <?php endif; ?>
                </tr>
                <tr>
                    <th>Категория</th>
                    <td>
                        <select name="addProduct-selectCategory">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Цена</th>
                    <td><input type="number" min="0" name="addProduct-price"></td>
                    <?php if(isset($errorname2)): ?>
                        <div>Поле "Цена" не может быть пустым</div>
                    <?php endif; ?>
                </tr>
                <tr>
                    <th>Количество</th>
                    <td><input type="number" min="0" name="addProduct-quantity"></td>
                    <?php if(isset($errorname3)): ?>
                        <div>Поле "Количество" не может быть пустым</div>
                    <?php endif; ?>
                </tr>
                <tr>
                    <th>Страна</th>
                    <td><input type="text" name="addProduct-country"></td>
                    <?php if(isset($errorname4)): ?>
                        <div>Поле "Страна" не может быть пустым</div>
                    <?php endif; ?>
                </tr>
                <tr>
                    <th>Год выпуска</th>
                    <td><input type="number" min="1900" max="2024" step="1" value="2024"
                            name="addProduct-yearrelease"></td>
                    <?php if(isset($errorname5)): ?>
                        <div>Поле "Год выпуска" не может быть пустым</div>
                    <?php endif; ?>
                </tr>
                <tr>
                    <th>Модель</th>
                    <td><input type="text" name="addProduct-model"></td>
                    <?php if(isset($errorname6)): ?>
                        <div>Поле "Модель" не может быть пустым</div>
                    <?php endif; ?>
                </tr>
                <tr>
                    <th>Картинка</th>
                    <td><input type="file" name="image" accept="image/png, image/jpeg"></td>
                </tr>
            </table>
            <input name="addProduct" type="submit" value="Добавить товар">
        </form>

        <h2 class="h1-1">Добавление категории</h2>
        <form class="h1-1" method="POST" action="admin">
            <?php if(isset($addCategory)): ?>
                <div>Вы добавили категорию</div>
            <?php endif; ?>
            <?php echo csrf_field(); ?>
            <input name="categoryName" type="text">
            <input name="addCategory" type="submit" value="Добавить категорию">
        </form>
        <h2 class="h1-1">Удаление категории</h2>
        <form class="h1-1" method="POST" action="admin">
            <?php if(isset($delCategory)): ?>
                <div>Вы удалили категорию</div>
            <?php endif; ?>
            <?php echo csrf_field(); ?>
            <select name="selectCategory">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <input name="delCategory" type="submit" value="Удалить категорию">
        </form>
        <h2 class="h1-1">Управление заказми</h2>
        <?php $__currentLoopData = $ordersNEW; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderNEW): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form method="POST" action="admin">
            <?php echo csrf_field(); ?>
            <div style="border: 2px black solid; border-radius:20px;margin-bottom:10px; padding:10px;">
                <?php $idthisbasket = $orderNEW->id_basket; ?>
                <?php $__currentLoopData = $productsFromBasket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productFromBasket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($productFromBasket->id_busket == $idthisbasket): ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            if ($product->id == $productFromBasket->id_products) {
                                $id = $product->id;
                                $name = $product->name;
                                $maxquantity = $product->quantity;
                                $thisquantity = $productFromBasket->quantity;
                                $imgsrc = $product->img_src;
                                break;
                            }
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="product">
                            <div>
                                <img class="img" src="<?php echo e(asset('images/' . $imgsrc)); ?>">
                            </div>
                            <div class="flexblock">
                                <div>
                                    <span>(id - <?php echo e($id); ?>)</span>
                                    <span><b><?php echo e($name); ?></b></span>
                                </div>
                                <div class="quant">Количество: <?php echo e($thisquantity); ?></div>
                                <input hidden name="neworder" value="<?php echo e($orderNEW->id); ?>">
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <select name="selectStatus">
                    <option value="новый">новый</option>
                    <option value="подтверждённый">подтверждённый</option>
                    <option value="отменённый">отменённый</option>
                </select>
                <input class="btn btn-warning" type="submit" name="changestatus" value="Изменить статус">
                <br>
                <textarea style="max-width: 600px;width:100%;" name="description"></textarea>
            </div>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</body>

</html>
<?php /**PATH D:\OSPanel\domains\OnlineShop\resources\views/admin.blade.php ENDPATH**/ ?>