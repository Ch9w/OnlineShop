<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        html,
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif
        }

        .h1-1 {
            text-align: center;
        }

        a {
            text-decoration: none;
            color: black;
        }

        header {
            font-size: 24px;
            background-color: rgb(200, 200, 200);
            display: flex;
            justify-content: center;
        }

        .header-div1 {
            width: 90%;
            display: flex;
            justify-content: space-between;
        }

        .content {
            margin: 0 auto;
            width: 90%;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }

        .card {
            align-items: center;
            text-align: center;
        }

        .product {
            border: 1px solid gray;
            border-radius: 20px;
            padding: 10px;
            display: flex;
            margin-bottom: 10px;
        }

        .img {
            height: 200px;
            width: fit-content;
            box-sizing: border-box;
            padding: 10px;
        }

        .flexblock {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .flexbuttons {
            display: flex;
        }
    </style>

</head>

<body>
    <header>
        <div class="header-div1">
            <div>
                <a href='aboutus'>Copy Star</a>
            </div>
            <div>
                <a href='catalog'>Каталог</a>
                <a href='wherefindus'>Где нас найти?</a>
            </div>
            <div>
                <?php if(Auth::check()): ?>
                    <a href='basket'>Корзина</a>
                    <a href='orders'>Заказы</a>
                    <a href='logout'>выйти</a>
                <?php else: ?>
                    <a href='login'>Вход</a>
                <?php endif; ?>
            </div>
        </div>
    </header>
    <div class="content">
        <h1 class="h1-1">Ваши заказы</h1>
        <div style="max-width: 1200px; margin: 0 auto;">
            <h1 class="h1-1">Новые заказы</h1>
            <?php $__currentLoopData = $ordersNEW; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderNEW): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form method="POST" action="orders">
                    <?php echo csrf_field(); ?>
                    <div style="border: 2px black solid; border-radius:20px;margin-bottom:10px; padding:10px;">
                        <?php $idthisbasket = $orderNEW->id_basket; ?>
                        <?php $__currentLoopData = $productsFromBasket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productFromBasket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($productFromBasket->id_busket == $idthisbasket): ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    if ($product->id == $productFromBasket->id_products) {
                                        $id = $product->id;
                                        $name = $product->name;
                                        $maxquantity = $product->quantity;
                                        $thisquantity = $productFromBasket->quantity;
                                        $imgsrc = $product->img_src;
                                        break;
                                    }
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="product">
                                    <div>
                                        <img class="img" src="<?php echo e(asset('images/' . $imgsrc)); ?>">
                                    </div>
                                    <div class="flexblock">
                                        <div>
                                            <span>(id - <?php echo e($id); ?>)</span>
                                            <span><b><?php echo e($name); ?></b></span>
                                        </div>
                                        <div class="quant">Количество: <?php echo e($thisquantity); ?></div>
                                        <input hidden name="neworder" value="<?php echo e($orderNEW->id); ?>">
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <input class="btn btn-danger" type="submit" name="delNEWorder" value="Удалить заказ">
                    </div>
                </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <h1 class="h1-1">Старые заказы</h1>
            <?php $__currentLoopData = $ordersOLD; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderOLD): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="border: 2px black solid; border-radius:20px;margin-bottom:10px;">
                    <?php $idthisbasket = $orderOLD->id_basket; ?>
                    <?php $__currentLoopData = $productsFromBasket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productFromBasket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($productFromBasket->id_busket == $idthisbasket): ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                if ($product->id == $productFromBasket->id_products) {
                                    $id = $product->id;
                                    $name = $product->name;
                                    $maxquantity = $product->quantity;
                                    $thisquantity = $productFromBasket->quantity;
                                    $imgsrc = $product->img_src;
                                    break;
                                }
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="product">
                                <div>
                                    <img class="img" src="<?php echo e(asset('images/' . $imgsrc)); ?>">
                                </div>
                                <div class="flexblock">
                                    <div>
                                        <span>(id - <?php echo e($id); ?>)</span>
                                        <span><b><?php echo e($name); ?></b></span>
                                    </div>
                                    <div class="quant">Количество: <?php echo e($thisquantity); ?></div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div>Статус: <?php echo e($orderOLD->status); ?></div>
                    <?php if($orderOLD->status=="отменённый"): ?>
                    <div>Причина: <?php echo e($orderOLD->description); ?></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</body>

</html>
<?php /**PATH C:\OSPanel\domains\lomov\OnlineShop\resources\views/orders.blade.php ENDPATH**/ ?>