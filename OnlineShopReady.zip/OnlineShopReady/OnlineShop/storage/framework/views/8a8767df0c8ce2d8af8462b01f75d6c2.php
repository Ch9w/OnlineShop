<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        html,
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif
        }

        .h1-1 {
            text-align: center;
        }

        a {
            text-decoration: none;
            color: black;
        }

        header {
            font-size: 24px;
            background-color: rgb(200, 200, 200);
            display: flex;
            justify-content: center;
        }

        .header-div1 {
            width: 90%;
            display: flex;
            justify-content: space-between;
        }

        .content {
            margin: 0 auto;
            width: 90%;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }

        .card {
            align-items: center;
            text-align: center;
        }

        .product {
            border: 1px solid gray;
            border-radius: 20px;
            padding: 10px;
            display: flex;
        }

        .img {
            height: 200px;
            width: fit-content;
            box-sizing: border-box;
            padding: 10px;
        }

        .flexblock {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .flexbuttons {
            display: flex;
        }

        .quant {
            margin: auto auto;
        }
    </style>
</head>

<body>
    <header>
        <div class="header-div1">
            <div>
                <a href='aboutus'>Copy Star</a>
            </div>
            <div>
                <a href='catalog'>Каталог</a>
                <a href='wherefindus'>Где нас найти?</a>
            </div>
            <div>
                <?php if(Auth::check()): ?>
                    <a href='basket'>Корзина</a>
                    <a href='orders'>Заказы</a>
                    <a href='logout'>выйти</a>
                <?php else: ?>
                    <a href='login'>Вход</a>
                <?php endif; ?>
            </div>
        </div>
    </header>
    <div class="content">
        <h1 class="h1-1">Ваша коризна</h1>
        <div style="margin: 0 auto; max-width:1200px;">
            <div>
                <?php $__currentLoopData = $productsFromBasket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productFromBasket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        if ($product->id == $productFromBasket->id_products) {
                            $id = $product->id;
                            $name = $product->name;
                            $maxquantity = $product->quantity;
                            $thisquantity = $productFromBasket->quantity;
                            $imgsrc = $product->img_src;
                            break;
                        }
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="product">
                        <div>
                            <img class="img" src="<?php echo e(asset('images/' . $imgsrc)); ?>">
                        </div>
                        <div class="flexblock">
                            <div>
                                <span>(id - <?php echo e($id); ?>)</span>
                                <span><b><?php echo e($name); ?></b></span>
                            </div>
                            <div class="flexbuttons">
                                <span>
                                    <form method="POST" action="basket">
                                        <?php echo csrf_field(); ?>
                                        <input hidden name="idProduct" value="<?php echo e($id); ?>">
                                        <input class="btn btn-danger" name="reduceProduct" type="submit"
                                            value="-">
                                    </form>
                                </span>
                                <div class="quant"><?php echo e($thisquantity); ?></div>
                                <span>
                                    <form method="POST" action="basket">
                                        <?php echo csrf_field(); ?>
                                        <input hidden name="idProduct" value="<?php echo e($id); ?>">
                                        <input style="margin-right: 10px;" class="btn btn-success"
                                            name="increaseProduct" type="submit" value="+">
                                    </form>
                                </span>
                                <span>
                                    <form method="POST" action="basket">
                                        <?php echo csrf_field(); ?>
                                        <input hidden name="idProduct" value="<?php echo e($id); ?>">
                                        <input class="btn btn-secondary" name="deleteProduct" type="submit"
                                            value="Убрать из корзины">
                                    </form>
                                </span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($productsFromBasket) > 0): ?>
                    <form style="display: flex;" action="basket" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="text" class="form-control w-25" name="password">
                        <input style="margin-top: 10px;" type="submit" class="btn btn-info" name="orderBasket"
                            value="Оформить заказ">
                        <?php if(isset($errorpassword)): ?>
                            <div>Неверный пароль</div>
                        <?php endif; ?>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\OSPanel\domains\OnlineShop\resources\views/basket.blade.php ENDPATH**/ ?>