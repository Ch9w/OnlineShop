<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <header>
        <div>Copy Star</div>
        <div>
            <a href=''>О нас</a>
            <a href=''>Каталог</a>
            <a href=''>Где нас найти?</a>
        </div>
        <div>
            <a>Вход</a>
        </div>
    </header>
    <h1>Это приватная страница для аутентифицированных пользователей</h1>
</body>
<style>
header {
    background-color: grey;
    display: flex;
    justify-content: space-between;
}
</style>

</html>
<?php /**PATH C:\OSPanel\domains\lomov\OnlineShop\resources\views/private.blade.php ENDPATH**/ ?>