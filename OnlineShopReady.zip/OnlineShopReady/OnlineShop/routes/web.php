<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthorizationController;
use App\Http\Controllers\RegistrationController;
use App\Http\Controllers\CatalogController;
use App\Http\Controllers\AboutUsController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\BasketController;
use App\Http\Controllers\OrderController;

use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::name('user.')->group(function () {
    Route::view('/aboutus', 'aboutus')->middleware('auth')->name('aboutus');
    Route::get('/login', function () {
        if (Auth::check()) {
            return redirect(route('user.aboutus'));
        }
        return view('login');
    })->name('login');
    Route::post('/login', [AuthorizationController::class, 'login']);
    Route::get('/logout', function () {
        Auth::logout();
        return redirect(route('user.aboutus'));
    })->name('logout');
    Route::get('/registration', function () {
        if (Auth::check()) {
            return redirect(route('user.aboutus'));
        }
        return view('registration');
    })->name('registration');
    Route::post('/registration', [RegistrationController::class, 'save']);

    Route::get('/wherefindus', function () {
        return view('wherefindus');
    })->name('wherefindus');

    Route::get('/aboutus', [AboutUsController::class, 'aboutus'])->name('aboutus');
    Route::get('/catalog', [CatalogController::class, 'catalog'])->name('catalog');
    Route::post('/catalog', [CatalogController::class, 'ProductFromBusket']);

    Route::get('/thistovar/{id}', [CatalogController::class, 'thistovar'])->name('thistovar');
    Route::post('/thistovar/{id}', [CatalogController::class, 'thistovarlogic']);

    Route::get('/basket', [BasketController::class, 'getBusket'])->name('basket');
    Route::post('/basket', [BasketController::class, 'postBusket']);


    Route::get('/orders', [OrderController::class, 'getOrders'])->name('orders');
    Route::post('/orders', [OrderController::class, 'postOrders']);


    Route::get('/admin', [AdminController::class, 'open'])->name('admin');
    Route::post('/admin', [AdminController::class, 'operation']);
});
