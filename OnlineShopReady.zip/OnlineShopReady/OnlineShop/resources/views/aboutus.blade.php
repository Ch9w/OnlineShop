<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        html,
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif
        }

        a {
            text-decoration: none;
            color: black;
        }

        header {
            font-size: 24px;
            background-color: rgb(200, 200, 200);
            display: flex;
            justify-content: center;
        }

        .header-div1 {
            width: 90%;
            display: flex;
            justify-content: space-between;
        }

        .content {
            margin: 0 auto;
            width: 90%;
        }

        .div-logo {
            width: fit-content;
            margin: 0 auto;
            text-align: center;
        }

        .div1 {
            text-align: center;
            margin: 0 auto;
        }

        .div1 div {
            width: 100%;
        }

        .carouselBox {
            display: flex;
            justify-content: center;
        }

        .carousel-img {
            height: 400px;
        }

        .carousel-name {
            display: flex;
            align-items: center;
            padding-left: 6%;
            font-size: 32px
        }

        .h2-center {
            text-align: center
        }

        .carousel-control-prev {
            background-color: black;
            width: fit-content;
            height: fit-content;
            padding: 20px;
            margin: auto 0;
            border-radius: 8px 0 0 8px;
        }

        .carousel-control-next {
            background-color: black;
            width: fit-content;
            height: fit-content;
            padding: 20px;
            margin: auto 0;
            border-radius: 0 8px 8px 0;
        }
    </style>

</head>

<body>
    <header>
        <div class="header-div1">
            <div>
                <a href='aboutus'>Copy Star</a>
            </div>
            <div>
                <a href='catalog'>Каталог</a>
                <a href='wherefindus'>Где нас найти?</a>
            </div>
            <div>
                @if (Auth::check())
                    @if (Auth::user()->role == 'admin')
                        <a href='admin'>(Консоль адмиминистратора)</a>
                    @endif

                    <a href='basket'>Корзина</a>
                    <a href='orders'>Заказы</a>
                    <a href='logout'>выйти</a>
                @else
                    <a href='login'>Вход</a>
                @endif
            </div>
        </div>
    </header>
    <div class="content">
        <h2 class="h2-center">Наши новинки</h2>
        <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                @foreach ($newproducts as $product)
                    @if ($loop->first)
                        <div class="carousel-item active">
                            <div class="carouselBox">
                                <div>
                                    <img class="carousel-img" src="{{ asset('images/' . $product->img_src) }}"
                                        class="card-img-top w-75 mx-auto">
                                </div>
                                <div class="carousel-name"> <a
                                        href="thistovar/{{ $product->id }}">{{ $product->name }}</a></div>
                            </div>
                        </div>
                    @else
                        <div class="carousel-item">
                            <div class="carouselBox">
                                <div>
                                    <img class="carousel-img" src="{{ asset('images/' . $product->img_src) }}"
                                        class="card-img-top w-75 mx-auto">
                                </div>
                                <div class="carousel-name"> <a
                                        href="thistovar/{{ $product->id }}">{{ $product->name }}</a></div>
                            </div>
                        </div>
                    @endif
                @endforeach
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"
                    data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"
                    data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
        <div class="div-logo">
            <img class="logo" src="{{ asset('images/logo.png') }}">
        </div>
        <div style="max-width: 800px" class="div1">
            <div>
                <h2>Принтеры: качество, сервис, инновации.</h2>
                <div>Мы предлагаем широкий ассортимент принтеров. У нас вы
                    найдёте качественные товары от ведущих производителей по доступным ценам. Мы предоставляем
                    гарантию
                    на всю продукцию и оперативную доставку. Обращайтесь к нам, чтобы купить принтер для
                    вашего бизнеса или дома.</div>
            </div>
        </div>
    </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
</script>

</html>
