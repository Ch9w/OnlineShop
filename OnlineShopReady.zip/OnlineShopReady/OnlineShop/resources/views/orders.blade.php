<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        html,
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif
        }

        .h1-1 {
            text-align: center;
        }

        a {
            text-decoration: none;
            color: black;
        }

        header {
            font-size: 24px;
            background-color: rgb(200, 200, 200);
            display: flex;
            justify-content: center;
        }

        .header-div1 {
            width: 90%;
            display: flex;
            justify-content: space-between;
        }

        .content {
            margin: 0 auto;
            width: 90%;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }

        .card {
            align-items: center;
            text-align: center;
        }

        .product {
            border: 1px solid gray;
            border-radius: 20px;
            padding: 10px;
            display: flex;
            margin-bottom: 10px;
        }

        .img {
            height: 200px;
            width: fit-content;
            box-sizing: border-box;
            padding: 10px;
        }

        .flexblock {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .flexbuttons {
            display: flex;
        }
    </style>

</head>

<body>
    <header>
        <div class="header-div1">
            <div>
                <a href='aboutus'>Copy Star</a>
            </div>
            <div>
                <a href='catalog'>Каталог</a>
                <a href='wherefindus'>Где нас найти?</a>
            </div>
            <div>
                @if (Auth::check())
                    <a href='basket'>Корзина</a>
                    <a href='orders'>Заказы</a>
                    <a href='logout'>выйти</a>
                @else
                    <a href='login'>Вход</a>
                @endif
            </div>
        </div>
    </header>
    <div class="content">
        <h1 class="h1-1">Ваши заказы</h1>
        <div style="max-width: 1200px; margin: 0 auto;">
            <h1 class="h1-1">Новые заказы</h1>
            @foreach ($ordersNEW as $orderNEW)
                <form method="POST" action="orders">
                    @csrf
                    <div style="border: 2px black solid; border-radius:20px;margin-bottom:10px; padding:10px;">
                        <?php $idthisbasket = $orderNEW->id_basket; ?>
                        @foreach ($productsFromBasket as $productFromBasket)
                            @if ($productFromBasket->id_busket == $idthisbasket)
                                @foreach ($products as $product)
                                    <?php
                                    if ($product->id == $productFromBasket->id_products) {
                                        $id = $product->id;
                                        $name = $product->name;
                                        $maxquantity = $product->quantity;
                                        $thisquantity = $productFromBasket->quantity;
                                        $imgsrc = $product->img_src;
                                        break;
                                    }
                                    ?>
                                @endforeach
                                <div class="product">
                                    <div>
                                        <img class="img" src="{{ asset('images/' . $imgsrc) }}">
                                    </div>
                                    <div class="flexblock">
                                        <div>
                                            <span>(id - {{ $id }})</span>
                                            <span><b>{{ $name }}</b></span>
                                        </div>
                                        <div class="quant">Количество: {{ $thisquantity }}</div>
                                        <input hidden name="neworder" value="{{ $orderNEW->id }}">
                                    </div>
                                </div>
                            @endif
                        @endforeach
                        <input class="btn btn-danger" type="submit" name="delNEWorder" value="Удалить заказ">
                    </div>
                </form>
            @endforeach
            <h1 class="h1-1">Старые заказы</h1>
            @foreach ($ordersOLD as $orderOLD)
                <div style="border: 2px black solid; border-radius:20px;margin-bottom:10px;">
                    <?php $idthisbasket = $orderOLD->id_basket; ?>
                    @foreach ($productsFromBasket as $productFromBasket)
                        @if ($productFromBasket->id_busket == $idthisbasket)
                            @foreach ($products as $product)
                                <?php
                                if ($product->id == $productFromBasket->id_products) {
                                    $id = $product->id;
                                    $name = $product->name;
                                    $maxquantity = $product->quantity;
                                    $thisquantity = $productFromBasket->quantity;
                                    $imgsrc = $product->img_src;
                                    break;
                                }
                                ?>
                            @endforeach
                            <div class="product">
                                <div>
                                    <img class="img" src="{{ asset('images/' . $imgsrc) }}">
                                </div>
                                <div class="flexblock">
                                    <div>
                                        <span>(id - {{ $id }})</span>
                                        <span><b>{{ $name }}</b></span>
                                    </div>
                                    <div class="quant">Количество: {{ $thisquantity }}</div>
                                </div>
                            </div>
                        @endif
                    @endforeach
                    <div>Статус: {{$orderOLD->status}}</div>
                    @if($orderOLD->status=="отменённый")
                    <div>Причина: {{$orderOLD->description}}</div>
                    @endif
                </div>
            @endforeach

        </div>
    </div>
</body>

</html>
