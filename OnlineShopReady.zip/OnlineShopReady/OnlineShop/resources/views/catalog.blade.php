<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        html,
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif
        }

        .h1-1 {
            text-align: center;
        }

        a {
            text-decoration: none;
            color: black;
        }

        header {
            font-size: 24px;
            background-color: rgb(200, 200, 200);
            display: flex;
            justify-content: center;
        }

        .header-div1 {
            width: 90%;
            display: flex;
            justify-content: space-between;
        }

        .content {
            margin: 0 auto;
            width: 90%;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        .card {
            align-items: center;
            text-align: center;
        }

        .img {
            height: 300px;
            width: fit-content;
            box-sizing: border-box;
            padding: 10px;
        }

        @media screen and (width <=1200px) {
            .cards {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media screen and (width <=768px) {
            .cards {
                grid-template-columns: repeat(1, 1fr);
            }
        }
    </style>
</head>

<body>
    <header>
        <div class="header-div1">
            <div>
                <a href='aboutus'>Copy Star</a>
            </div>
            <div>
                <a href='catalog'>Каталог</a>
                <a href='wherefindus'>Где нас найти?</a>
            </div>
            <div>
                @if (Auth::check())
                    <a href='basket'>Корзина</a>
                    <a href='orders'>Заказы</a>
                    <a href='logout'>выйти</a>
                @else
                    <a href='login'>Вход</a>
                @endif
            </div>
        </div>
    </header>

    <div class="content">
        <h1 class="h1-1">Каталог товаров</h1>
        <form style ="margin-bottom: 10px;" action="catalog" method="GET">
            <table>
                <tr>
                    <td>Упорядочить товары по </td>
                    <td>
                        <select name="sorting">
                            <option value="date" {{ Session::get('sorting') == 'date' ? 'selected' : '' }}>новизне
                            </option>
                            <option value="yearrelease"
                                {{ Session::get('sorting') == 'yearrelease' ? 'selected' : '' }}>году производства
                            </option>
                            <option value="name" {{ Session::get('sorting') == 'name' ? 'selected' : '' }}>
                                наименованию</option>
                            <option value="price" {{ Session::get('sorting') == 'price' ? 'selected' : '' }}>цене
                            </option>
                        </select>
                        <select name="orderBy">
                            <option value="ADESC" {{ Session::get('orderBy') == 'ADESC' ? 'selected' : '' }}>по
                                убыванию</option>
                            <option value="DESC" {{ Session::get('orderBy') == 'DESC' ? 'selected' : '' }}>по
                                возрастанию</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Выбрать категорию </td>
                    <td>
                        <select name="category">
                            <option value="all"{{ Session::get('category') == 'all' ? 'selected' : '' }}>всё</option>
                            @foreach ($categories as $category)
                                <option value="{{ $category->id }}"
                                    {{ Session::get('category') == $category->id ? 'selected' : '' }}>
                                    {{ $category->name }}</option>
                            @endforeach
                        </select>
                    </td>
                </tr>
            </table>
            <input type="submit" name="search" value="Найти">
        </form>
        <div class="cards">
            @foreach ($catalog as $tovar)
                <form method="POST">
                    @csrf
                    <div class="card">
                        <a href="thistovar/{{ $tovar->id }}">
                            <img src="{{ asset('images/' . $tovar->img_src) }}" class="card-img-top mx-auto img">
                            <div class="card-body">
                                <h5 class="card-title">{{ $tovar->name }}</h5>
                                <p class="card-text">{{ $tovar->price }} рублей</p>
                                @if (Auth::check())
                                    <?php
                                    $fromBusket = 0;
                                    ?>
                                    @foreach ($productsFromBasket as $productFromBasket)
                                        @if ($productFromBasket->id_products == $tovar->id)
                                            <?php
                                            $fromBusket++;
                                            ?>
                                        @endif
                                    @endforeach
                                    @if ($fromBusket > 0)
                                        <input hidden name="idProduct" value="{{ $tovar->id }}">
                                        <input type="submit" name="delProductFromBusket" class="btn btn-warning"
                                            value="В корзине">
                                    @else
                                        <input hidden name="idProduct" value="{{ $tovar->id }}">
                                        <input type="submit" name="addProductFromBusket" class="btn btn-primary"
                                            value="В корзину">
                                    @endif
                                    @if (Auth::user()->role == 'admin')
                                        <form action="catalog" method="POST">
                                            @csrf
                                            <input hidden name="changeProduct" value="{{ $tovar->id }}">
                                            <input class="btn btn-warning" type="submit" value="Отредактировать товар">
                                        </form>
                                        <form action="catalog" method="POST">
                                            @csrf
                                            <input hidden name="delProduct" value="{{ $tovar->id }}">
                                            <input class="btn btn-danger" type="submit" value="Удалить товар">
                                        </form>
                                    @endif
                                @endif
                            </div>
                        </a>
                    </div>
                </form>
            @endforeach
        </div>
    </div>
</body>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
</script>

</html>
