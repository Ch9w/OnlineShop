<body>
    <form method='POST' action="{{ route('user.registration') }}">
        @csrf
        <h1>Регистрация</h1>
        <table>
            <tr>
                <td>name</td>
                <td><input id="name" name="name" type="text" placeholder="Ваше имя" value="{{ old('name') }}">
                    @error('name')
                    <div>{{ $message }}</div>
                    @enderror
                </td>
            </tr>
            <tr>
                <td>surname</td>
                <td><input id="surname" name="surname" type="text" placeholder="Ваша фамилия" value="{{ old('surname') }}">
                    @error('surname')
                    <div>{{ $message }}</div>
                    @enderror
                </td>
            </tr>
            <tr>
                <td>patronymic</td>
                <td><input id="patronymic" name="patronymic" type="text" placeholder="Ваше отчество" value="{{ old('patronymic') }}">
                    @error('patronymic')
                    <div>{{ $message }}</div>
                    @enderror
                </td>
            </tr>
            <tr>
                <td>login</td>
                <td><input id="login" name="login" type="text" placeholder="Ваш логин" value="{{ old('login') }}">
                    @error('login')
                    <div>{{ $message }}</div>
                    @enderror
                </td>
            </tr>
            <tr>
                <td>email</td>
                <td><input id="email" name="email" type="text" placeholder="Ваш email" value="{{ old('email') }}">
                    @error('email')
                    <div>{{ $message }}</div>
                    @enderror
                </td>
            </tr>
            <tr>
                <td>password</td>
                <td><input id="password" name="password" type="password" value="" placeholder="Пароль">
                    @error('password')
                    <div>{{ $message }}</div>
                    @enderror
                </td>
            </tr>
            <tr>
                <td>password repeat</td>
                <td><input id="password_repeat" name="password_repeat" type="password" value="" placeholder="Повторите пароль">
                    @error('password_repeat')
                    <div>{{ $message }}</div>
                    @enderror
                </td>
            </tr>
            <tr>
                <td>Я согласен с правилами регистрации</td>
                <td><input id="rules" name="rules" type="checkbox" value="true">
                    @error('rules')
                    <div>{{ $message }}</div>
                    @enderror
                </td>
            </tr>
        </table>
        <div>
            <button name="sendMe" value="1">Зарегистрироваться</button>
        </div>
    </form>
</body>
<style>
    html,
    body {
        margin: 0;
        font-family: Arial, Helvetica, sans-serif
    }

    body {
        display: flex;
        justify-content: center;
    }
</style>