<body>

    <form method='POST' action="{{ route('user.login') }}">
        @csrf
        <h1>Вход</h1>
        <table>
            <tr>
                <td>Ваш login</td>
                <td><input id="login" name="login" type="text" placeholder="Login" value="{{ old('login') }}">
                    @error('login')
                    <div>{{ $message }}</div>
                    @enderror
                </td>
            </tr>
            <tr>
                <td>Пароль</td>
                <td><input id="password" name="password" type="text" value="" placeholder="Пароль">
                    @error('password')
                    <div>{{ $message }}</div>
                    @enderror
                </td>
            </tr>
        </table>
        <div class="form-buttons">
            <button name="sendMe" value="1">Войти</button>
            <a href="registration">Зарегистрироваться</a>
        </div>
    </form>
</body>

<style>
    html,
    body {
        margin: 0;
        font-family: Arial, Helvetica, sans-serif
    }

    body {
        display: flex;
        justify-content: center;
    }

    .form-buttons {
        display: flex;
        justify-content: space-between;
    }
</style>